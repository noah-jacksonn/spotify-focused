import { createSegtestPickStore } from "./segtestPickStore.js";

/**
 * Standard Web Request/Response handlers keep the Node disk mirror independent
 * of Next.js. A host supplies only its own .segtest/picks.json path. Keeping
 * this server entry separate prevents Node filesystem code entering the UI.
 */
export function createSegtestRoute(
  filePath: string,
  development = process.env.NODE_ENV === "development",
) {
  const store = createSegtestPickStore(filePath);
  return {
    async GET() {
      if (!development) return new Response(null, { status: 404 });
      return Response.json(await store.read());
    },
    async POST(request: Request) {
      if (!development) return new Response(null, { status: 404 });
      const body: unknown = await request.json().catch(() => null);
      if (!isPick(body)) {
        return Response.json({ error: "Expected { id, title, value } strings" }, { status: 400 });
      }
      await store.save(body.id, body.title, body.value);
      return Response.json({ ok: true });
    },
  };
}

/** Validate the entire request before asking the disk store to mutate data. */
function isPick(value: unknown): value is { id: string; title: string; value: string } {
  return value !== null && typeof value === "object"
    && "id" in value && typeof value.id === "string"
    && "title" in value && typeof value.title === "string"
    && "value" in value && typeof value.value === "string";
}
