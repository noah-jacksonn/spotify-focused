"use client";

import {
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type KeyboardEvent as ReactKeyboardEvent,
  type PointerEvent as ReactPointerEvent,
  type ReactNode,
  type RefObject,
} from "react";
import { createPortal } from "react-dom";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import {
  Root as SegmentedControl,
  List as SegmentedControlList,
  Trigger as SegmentedControlTrigger,
} from "@radix-ui/react-tabs";
import { useMounted } from "./use-mounted.js";
import { attachTouchScroll } from "./touch-scroll.js";
import "./segtest.css";
import { SegtestIdContext, readSegtestPick, reportSegtestPick, saveSegtestPick } from "./segtest-picks.js";
import { SEGTEST_FOOTER_BUTTON_CLASS, SEGTEST_DOT_DIAMETER, SEGTEST_EDGE_INSET, SEGTEST_PANEL_GAP, SegtestPanelResizeHandle, useSegtestPanelSize, type SegtestPanelRectangle } from "./segtest-panel-size.js";

/**
 * SEGTEST USAGE — read before creating or changing a comparison.
 * These rules live with the shared implementation, not in every AGENTS.md.
 * Canonical source: /Users/noahjackson/segtest. Installed copies include src/
 * for reference; edit the canonical source and run `pnpm sync` there to update
 * every registered app. Commit each app's vendor/segtest archive and lockfile.
 * Do not publish to npm or replace this package with a per-project copy.
 *
 * NEW APP: run `node /Users/noahjackson/segtest/scripts/sync-consumers.mjs
 * --add /absolute/app/path` (one command), then add a development-only Node
 * /api/debug/segtest route using createSegtestRoute from @noah/segtest/route,
 * passing path.join(process.cwd(), ".segtest", "picks.json"). Gitignore .segtest/.
 * The app needs a next-themes ThemeProvider; package peers share the app's React.
 * CSS ships with the package; no shadcn imports or Tailwind configuration needed.
 *
 * WHEN ASKED FOR A SEGTEST: put a temporary comparison on the feature's existing
 * page. Give each adjustable property one labeled row. Use this scaffold rather
 * than building another dot, panel or rows; do not search history for a tester.
 * Keep the feature's values in its own useState. Keep explanatory test labels
 * inside the panel, not the product UI. Use a stable, feature-specific panel id.
 * Place its dot away from the feature (corner defaults to bottom-right).
 * Inside a modal, pass its root containerRef to keep the panel in the focus
 * scope and outside the scrolling content. Keep the reusable scaffold afterward.
 *
 * NUMBERS ALWAYS USE SLIDERS: sizes, spacing, opacity, durations, counts, etc.
 * Import SegtestSliderRow from @noah/segtest/slider; provide title, numeric value,
 * onChange, explicit min/max/step and optional unit (e.g. "px" or "ms"). Honor
 * Noah's requested range/starting value; otherwise choose a useful range.
 * CATEGORIES USE SegtestRow from @noah/segtest/panel: title, string[] options,
 * value, onChange. Numbered segments are only for explicitly requested discrete
 * comparisons. Do not turn a numeric property into strings to avoid a slider.
 *
 * import { DebugSegtestPanel, SegtestRow } from "@noah/segtest/panel";
 * import { SegtestSliderRow } from "@noah/segtest/slider";
 * <DebugSegtestPanel id="card">
 *   <SegtestSliderRow title="Padding" value={padding} onChange={setPadding}
 *     min={0} max={40} step={1} unit="px" />
 * </DebugSegtestPanel>
 *
 * PICKS AND LOCK-IN: rows restore localStorage and mirror via /api/debug/segtest
 * into that app's gitignored .segtest/picks.json. Read it at the start of follow-up
 * work instead of asking what Noah chose. "Lock in" / "lock everything" applies
 * all active rows' saved picks and removes their temporary state/options/panel.
 * A request to lock one row removes ONLY that row; preserve unmentioned rows and
 * saved values. Never infer a lock from silence. State which values were locked.
 *
 * DEVELOPMENT ONLY: nothing renders outside NODE_ENV=development. Drag the dot
 * to move; drag the bare lower-left handle to resize; size/position persist per id.
 * The bare lower-right icon changes the app's theme. Option-S toggles the panel
 * and focuses a row, Option-L changes theme, Tab/Shift-Tab cycle rows and footer
 * actions, arrows change categories/sliders. Physical key codes keep Option-S
 * working on macOS even though its typed character is ß. The iOS SwiftUI twin is
 * separate; this package is for React web apps.
 */

export type SegtestCorner = "top-left" | "top-right" | "bottom-left" | "bottom-right";

export function DebugSegtestPanel({
  id = "default",
  corner = "bottom-right",
  children,
  containerRef,
}: {
  id?: string;
  corner?: SegtestCorner;
  /** A modal host keeps keyboard focus in its scope; omit for page-wide tests. */
  containerRef?: RefObject<HTMLElement | null>;
  children: ReactNode;
}) {
  const mounted = useMounted();
  const [container, setContainer] = useState<HTMLElement | null>(null);
  useLayoutEffect(() => {
    // Resolve the host after its ref is attached, before the portal paints.
    setContainer(containerRef?.current ?? null);
  }, [containerRef]);
  if (process.env.NODE_ENV !== "development" || !mounted) return null;
  return createPortal(
    <SegtestOverlay key={id} id={id} corner={corner} container={container}>
      {children}
    </SegtestOverlay>,
    container ?? document.body,
  );
}

/** Categorical choices use Radix keyboard behavior, independent of the host's shadcn copy. */
export function SegtestRow<T extends string>({
  title,
  options,
  value,
  onChange,
}: {
  title: string;
  options: readonly T[];
  value: T;
  onChange: (value: T) => void;
}) {
  const id = useContext(SegtestIdContext);

  // Restore the saved pick on mount (a label that no longer matches an
  // option is ignored), otherwise record the starting value.
  useEffect(() => {
    const saved = readSegtestPick(id, title);
    if (saved !== null && (options as readonly string[]).includes(saved)) {
      if (saved !== value) onChange(saved as T);
      reportSegtestPick(id, title, saved);
    } else {
      reportSegtestPick(id, title, value);
    }
    // Mount only: later picks are saved in `select`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const select = (next: T) => {
    saveSegtestPick(id, title, next);
    onChange(next);
  };

  return (
    <div data-segtest-row className="segtest-row">
      <span className="segtest-label">
        {title}
      </span>
      <SegmentedControl value={value} onValueChange={(next) => select(next as T)}>
        <SegmentedControlList className="segtest-options" aria-label={title}>
          {options.map((option) => (
            <SegmentedControlTrigger className="segtest-option" key={option} value={option}>
              {option}
            </SegmentedControlTrigger>
          ))}
        </SegmentedControlList>
      </SegmentedControl>
    </div>
  );
}

// 18, not 24 (Noah 2026-09-23: a smaller dot); the 8 px center stays.
const DOT_DIAMETER = SEGTEST_DOT_DIAMETER;
const EDGE_INSET = SEGTEST_EDGE_INSET;
// Dot-to-panel gap (Noah 2026-09-23: 14 read as too far apart).
const PANEL_GAP = SEGTEST_PANEL_GAP;
const PANEL_MAX_WIDTH = 360;
const DRAG_THRESHOLD = 6;

type Point = { x: number; y: number };
type Size = { width: number; height: number };

function storageKey(id: string) {
  return `segtest.dot.${id}`;
}

function readStoredDot(id: string): Point | null {
  try {
    const raw = window.localStorage.getItem(storageKey(id));
    if (!raw) return null;
    const [x, y] = raw.split(",").map(Number);
    return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : null;
  } catch {
    return null;
  }
}

function writeStoredDot(id: string, point: Point) {
  try {
    window.localStorage.setItem(storageKey(id), `${point.x},${point.y}`);
  } catch {
    // Private mode or blocked storage: the dot just won't remember its spot.
  }
}

function clampDot(point: Point, bounds: Size): Point {
  const half = DOT_DIAMETER / 2;
  return {
    x: Math.min(Math.max(point.x, half), Math.max(half, bounds.width - half)),
    y: Math.min(Math.max(point.y, half), Math.max(half, bounds.height - half)),
  };
}

function defaultDot(corner: SegtestCorner, bounds: Size): Point {
  const x = corner.endsWith("left")
    ? EDGE_INSET + DOT_DIAMETER / 2
    : bounds.width - EDGE_INSET - DOT_DIAMETER / 2;
  const y = corner.startsWith("top")
    ? EDGE_INSET + DOT_DIAMETER / 2
    : bounds.height - EDGE_INSET - DOT_DIAMETER / 2;
  return { x, y };
}

function useViewportSize(container?: HTMLElement | null): Size {
  const [size, setSize] = useState<Size>(() => ({
    width: container?.clientWidth ?? window.innerWidth,
    height: container?.clientHeight ?? window.innerHeight,
  }));
  useEffect(() => {
    const update = () => setSize({ width: container?.clientWidth ?? window.innerWidth, height: container?.clientHeight ?? window.innerHeight });
    const observer = new ResizeObserver(update);
    if (container) observer.observe(container);
    window.addEventListener("resize", update);
    return () => { window.removeEventListener("resize", update); observer.disconnect(); };
  }, [container]);
  return size;
}

function SegtestOverlay({
  id,
  corner,
  children,
  container,
}: {
  id: string;
  corner: SegtestCorner;
  children: ReactNode;
  container?: HTMLElement | null;
}) {
  const bounds = useViewportSize(container);
  const { rectangle, resize, save } = useSegtestPanelSize(id, bounds);
  const [showsRows, setShowsRows] = useState(true);
  const [storedDot, setStoredDot] = useState<Point | null>(() => readStoredDot(id));
  const [panelSize, setPanelSize] = useState<Size>({ width: 0, height: 0 });
  const panelRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { isDark, toggleAppearance } = useAppearanceToggle();
  // The row the keyboard last used, so reopening with Option-S lands back on it.
  const lastFocusedRowIndexRef = useRef(0);
  // Set when Option-S opens the panel, so the effect below focuses a row once
  // it has rendered (a click on the dot leaves focus alone).
  const shouldFocusRowOnOpenRef = useRef(false);
  // last = the most recent dragged position, persisted once on pointer up
  const drag = useRef<{ pointerId: number; start: Point; origin: Point; panelOrigin: SegtestPanelRectangle | null; moved: boolean; last?: Point } | null>(null);

  useEffect(() => {
    if (!showsRows || !scrollRef.current) return;
    return attachTouchScroll(scrollRef.current);
  }, [showsRows]);

  // Resized panels keep their dot below the right corner. Moving that dot
  // translates the rectangle instead of snapping to automatic placement.
  const dot = clampDot(rectangle
    ? { x: rectangle.left + rectangle.width - DOT_DIAMETER / 2, y: rectangle.top + rectangle.height + PANEL_GAP + DOT_DIAMETER / 2 }
    : storedDot ?? defaultDot(corner, bounds), bounds);

  useLayoutEffect(() => {
    const panel = panelRef.current;
    if (!panel) return;
    const observer = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      setPanelSize({ width: panel.offsetWidth || width, height: panel.offsetHeight || height });
    });
    observer.observe(panel);
    // Measure the newly opened portal before paint.
    setPanelSize({ width: panel.offsetWidth, height: panel.offsetHeight });
    return () => observer.disconnect();
  }, [showsRows]);

  /**
   * Global shortcuts: Option-S toggles the panel, Option-L flips light/dark.
   * With several panels on one page, only the first listener flips the theme
   * (it marks the event handled), otherwise two flips would cancel out; every
   * panel still toggles on Option-S.
   */
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (!event.altKey || event.metaKey || event.ctrlKey) return;
      if (event.code === "KeyS") {
        event.preventDefault();
        // Holding the keys down would otherwise flicker the panel open and
        // closed; the repeats are still cancelled above so no "ß" gets typed.
        if (event.repeat) return;
        if (!showsRows) shouldFocusRowOnOpenRef.current = true;
        setShowsRows(!showsRows);
      } else if (event.code === "KeyL" && !event.defaultPrevented) {
        event.preventDefault();
        if (event.repeat) return;
        toggleAppearance();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [showsRows, toggleAppearance]);

  // After Option-S opens the panel, focus the selected option of the last
  // used row so the arrows and Tab work without clicking first.
  useEffect(() => {
    if (!showsRows || !shouldFocusRowOnOpenRef.current) return;
    shouldFocusRowOnOpenRef.current = false;
    focusRow(panelRef.current, lastFocusedRowIndexRef.current);
  }, [showsRows]);

  /**
   * Tab / Shift-Tab visit rows and the two footer controls (wrapping), so the
   * resize handle is reachable without a pointer. Option-S restores that stop.
   */
  const onPanelKeyDown = (event: ReactKeyboardEvent<HTMLDivElement>) => {
    if (event.key !== "Tab") return;
    const rows = getRows(panelRef.current);
    if (rows.length === 0) return;
    event.preventDefault();
    const currentRowIndex = getFocusedRowIndex(panelRef.current);
    // An unrecognized focus target starts at the first/last known stop.
    const nextRowIndex =
      currentRowIndex === -1
        ? event.shiftKey ? rows.length - 1 : 0
        : (currentRowIndex + (event.shiftKey ? -1 : 1) + rows.length) % rows.length;
    focusRow(panelRef.current, nextRowIndex);
  };
  const onPanelFocus = () => {
    const rowIndex = getFocusedRowIndex(panelRef.current);
    if (rowIndex !== -1) lastFocusedRowIndexRef.current = rowIndex;
  };

  const onPointerDown = useCallback(
    (event: ReactPointerEvent<HTMLButtonElement>) => {
      event.currentTarget.setPointerCapture(event.pointerId);
      drag.current = {
        pointerId: event.pointerId,
        start: { x: event.clientX, y: event.clientY },
        origin: dot,
        panelOrigin: rectangle,
        moved: false,
      };
    },
    [dot, rectangle],
  );

  const onPointerMove = useCallback(
    (event: ReactPointerEvent<HTMLButtonElement>) => {
      const current = drag.current;
      if (!current || current.pointerId !== event.pointerId) return;
      const dx = event.clientX - current.start.x;
      const dy = event.clientY - current.start.y;
      if (!current.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
      current.moved = true;
      if (current.panelOrigin) {
        resize({ ...current.panelOrigin, left: current.panelOrigin.left + dx, top: current.panelOrigin.top + dy });
        return;
      }
      const next = clampDot({ x: current.origin.x + dx, y: current.origin.y + dy }, bounds);
      current.last = next;
      setStoredDot(next);
    },
    [bounds, resize],
  );

  const onPointerUp = useCallback((event: ReactPointerEvent<HTMLButtonElement>) => {
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId) return;
    drag.current = null;
    // Persist the dot once, where the drag ends, instead of hitting
    // localStorage on every pointermove
    if (current.last) writeStoredDot(id, current.last);
    if (current.panelOrigin && current.moved) save();
    if (!current.moved) setShowsRows((value) => !value);
  }, [id, save]);

  // The panel grows away from the nearest vertical edge and stays inside the
  // viewport horizontally, so dragging the dot into a corner keeps the rows on
  // screen.
  // Before the first resize height follows content; afterwards the remembered
  // rectangle sets both dimensions and scrolling keeps every row accessible.
  const panelWidth = rectangle?.width ?? Math.min(PANEL_MAX_WIDTH, Math.max(0, bounds.width - 2 * EDGE_INSET));
  const halfWidth = panelSize.width / 2;
  const panelCenterX = Math.min(
    Math.max(dot.x, halfWidth + EDGE_INSET),
    Math.max(halfWidth + EDGE_INSET, bounds.width - halfWidth - EDGE_INSET),
  );
  const above = dot.y > bounds.height / 2;
  const rawTop = above
    ? dot.y - DOT_DIAMETER / 2 - PANEL_GAP - panelSize.height
    : dot.y + DOT_DIAMETER / 2 + PANEL_GAP;
  const panelTop = Math.min(
    Math.max(rawTop, EDGE_INSET),
    Math.max(EDGE_INSET, bounds.height - panelSize.height - EDGE_INSET),
  );

  return (
    <div className="segtest-overlay" style={{ position: container ? "absolute" : "fixed" }} data-segtest={id} data-theme={isDark ? "dark" : "light"}>
      {showsRows && (
        <div
          ref={panelRef}
          className="segtest-panel"
          data-vaul-no-drag
          style={{ left: rectangle?.left ?? panelCenterX - halfWidth, top: rectangle?.top ?? panelTop, width: panelWidth, height: rectangle?.height, maxHeight: Math.max(0, bounds.height - 2 * EDGE_INSET) }}
          onKeyDown={onPanelKeyDown}
          onFocus={onPanelFocus}
        >
          <div ref={scrollRef} className="segtest-rows">
            {/* Some mobile modal scroll locks search from the touch target's
                parent, skipping the target itself. Keep the gaps on an inner
                element so a swipe anywhere resolves to our scroll viewport. */}
            <div className="segtest-rows-content">
              <SegtestIdContext.Provider value={id}>{children}</SegtestIdContext.Provider>
            </div>
          </div>
          <div className="segtest-footer">
            <SegtestPanelResizeHandle panelRef={panelRef} bounds={bounds} onResize={resize} onCommit={save} />
            <AppearanceToggle />
          </div>
        </div>
      )}
      <button
        type="button"
        aria-label={showsRows ? "Hide design tester" : "Show design tester"}
        className="segtest-dot"
        style={{
          left: dot.x - DOT_DIAMETER / 2,
          top: dot.y - DOT_DIAMETER / 2,
          width: DOT_DIAMETER,
          height: DOT_DIAMETER,
        }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      >
        <span
          className="segtest-dot-center"
          style={{ opacity: showsRows ? 0.9 : 0.45 }}
        />
      </button>
    </div>
  );
}

/** Each feature row is one focus stop; the size and theme buttons follow. */
function getRows(panel: HTMLElement | null): HTMLElement[] {
  return panel ? Array.from(panel.querySelectorAll<HTMLElement>('[data-segtest-row], [data-segtest-panel-action]')) : [];
}

/** Which row or footer action holds focus, or -1 for an unrecognized target. */
function getFocusedRowIndex(panel: HTMLElement | null): number {
  return getRows(panel).findIndex((row) => row.contains(document.activeElement));
}

/**
 * Puts keyboard focus on a row's currently selected option (clamped to the
 * rows that exist, since rows come and go as picks get locked in).
 */
function focusRow(panel: HTMLElement | null, rowIndex: number) {
  const rows = getRows(panel);
  const row = rows[Math.min(rowIndex, rows.length - 1)];
  if (row?.matches("button")) { row.focus(); return; }
  row?.querySelector<HTMLElement>('[role="tab"][data-state="active"], input[type="range"]')?.focus();
}

/**
 * Bottom-right light/dark toggle, part of every segtest (Noah 2026-09-23).
 * Shows the mode a click switches TO — sun in dark, moon in light — and
 * writes the app's own theme setting. Option-L does the same from the keyboard.
 */
function AppearanceToggle() {
  const { isDark, toggleAppearance } = useAppearanceToggle();
  const Icon = isDark ? Sun : Moon;
  return (
    <button
      type="button"
      data-segtest-panel-action
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      className={SEGTEST_FOOTER_BUTTON_CLASS}
      onClick={toggleAppearance}
    >
      <Icon className="segtest-icon" />
    </button>
  );
}

/** Light/dark flip shared by the footer button and the Option-L shortcut, so both always agree. */
function useAppearanceToggle() {
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const toggleAppearance = useCallback(() => setTheme(isDark ? "light" : "dark"), [isDark, setTheme]);
  return { isDark, toggleAppearance };
}
