"use client";

import { useRef, useState, type KeyboardEvent, type PointerEvent, type RefObject } from "react";
import { MoveDiagonal2 } from "lucide-react";

// Share geometry with the panel so its handle, dot and viewport clamps agree.
export const SEGTEST_EDGE_INSET = 18;
export const SEGTEST_DOT_DIAMETER = 18;
export const SEGTEST_PANEL_GAP = 6;
const MIN_PANEL_WIDTH = 240;
const MIN_PANEL_HEIGHT = 110;

type Size = { width: number; height: number };
export type SegtestPanelRectangle = Size & { left: number; top: number };

/** Bare icons by request; keyboard focus remains visible without a fill. */
export const SEGTEST_FOOTER_BUTTON_CLASS = "segtest-footer-button";

/**
 * Remember freely resized geometry independently from feature-design picks.
 * An explicit position keeps the opposite corner still while resizing, rather
 * than re-anchoring to the dot each frame. The dot can still move the panel.
 */
export function useSegtestPanelSize(id: string, bounds: Size) {
  const [storedRectangle, setStoredRectangle] = useState(() => readRectangle(id));
  const latestRectangle = useRef(storedRectangle);
  const rectangle = storedRectangle ? clampPanelRectangle(storedRectangle, bounds) : null;

  const resize = (next: SegtestPanelRectangle) => {
    latestRectangle.current = clampPanelRectangle(next, bounds);
    setStoredRectangle(latestRectangle.current);
  };
  const save = () => {
    if (!latestRectangle.current) return;
    try {
      window.localStorage.setItem(`segtest.panel.rectangle.${id}`, JSON.stringify(latestRectangle.current));
    } catch {
      // The live drag still works when browser storage is unavailable.
    }
  };
  return { rectangle, resize, save };
}

/**
 * Bottom-left handle: left widens, right narrows, down makes taller.
 * Pointer capture keeps mouse, pen and touch drags alive outside the icon.
 * Arrow keys offer the same operation in 10px steps (40px with Shift).
 */
export function SegtestPanelResizeHandle({
  panelRef,
  bounds,
  onResize,
  onCommit,
}: {
  panelRef: RefObject<HTMLDivElement | null>;
  bounds: Size;
  onResize: (rectangle: SegtestPanelRectangle) => void;
  onCommit: () => void;
}) {
  const drag = useRef<{
    pointerId: number;
    x: number;
    y: number;
    scaleX: number;
    scaleY: number;
    origin: SegtestPanelRectangle;
  } | null>(null);

  const onPointerDown = (event: PointerEvent<HTMLButtonElement>) => {
    const panel = panelRef.current;
    if (!panel || event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.focus();
    event.currentTarget.setPointerCapture(event.pointerId);
    const screen = panel.getBoundingClientRect();
    drag.current = {
      pointerId: event.pointerId, x: event.clientX, y: event.clientY,
      scaleX: screen.width / panel.offsetWidth || 1,
      scaleY: screen.height / panel.offsetHeight || 1,
      origin: measurePanel(panel),
    };
  };
  const onPointerMove = (event: PointerEvent<HTMLButtonElement>) => {
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId) return;
    onResize(resizeFromBottomLeft(current.origin,
      (event.clientX - current.x) / current.scaleX,
      (event.clientY - current.y) / current.scaleY, bounds));
  };
  const finishDrag = (event: PointerEvent<HTMLButtonElement>) => {
    if (drag.current?.pointerId !== event.pointerId) return;
    drag.current = null;
    onCommit();
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  };
  const onKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    const panel = panelRef.current;
    if (!panel || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) return;
    event.preventDefault();
    event.stopPropagation();
    const step = event.shiftKey ? 40 : 10;
    const dx = event.key === "ArrowLeft" ? -step : event.key === "ArrowRight" ? step : 0;
    const dy = event.key === "ArrowUp" ? -step : event.key === "ArrowDown" ? step : 0;
    onResize(resizeFromBottomLeft(measurePanel(panel), dx, dy, bounds));
    onCommit();
  };

  return (
    <button
      type="button"
      data-segtest-panel-action
      aria-label="Resize design tester: drag or use arrow keys"
      title="Drag to resize"
      className={SEGTEST_FOOTER_BUTTON_CLASS}
      style={{ cursor: "nesw-resize", touchAction: "none", userSelect: "none" }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={finishDrag}
      onPointerCancel={finishDrag}
      onLostPointerCapture={finishDrag}
      onKeyDown={onKeyDown}
    >
      <MoveDiagonal2 className="segtest-icon" aria-hidden="true" />
    </button>
  );
}

/** Keep the full panel and its draggable dot inside the viewport/modal. */
function clampPanelRectangle(rectangle: SegtestPanelRectangle, bounds: Size): SegtestPanelRectangle {
  const bottomSpace = SEGTEST_EDGE_INSET + SEGTEST_DOT_DIAMETER + SEGTEST_PANEL_GAP;
  const availableWidth = Math.max(0, bounds.width - 2 * SEGTEST_EDGE_INSET);
  const availableHeight = Math.max(0, bounds.height - SEGTEST_EDGE_INSET - bottomSpace);
  const width = clamp(rectangle.width, Math.min(MIN_PANEL_WIDTH, availableWidth), availableWidth);
  const height = clamp(rectangle.height, Math.min(MIN_PANEL_HEIGHT, availableHeight), availableHeight);
  return {
    width, height,
    left: clamp(rectangle.left, SEGTEST_EDGE_INSET, Math.max(SEGTEST_EDGE_INSET, bounds.width - SEGTEST_EDGE_INSET - width)),
    top: clamp(rectangle.top, SEGTEST_EDGE_INSET, Math.max(SEGTEST_EDGE_INSET, bounds.height - bottomSpace - height)),
  };
}

/** Clamp against the fixed upper-right corner so the handle follows the hand. */
function resizeFromBottomLeft(origin: SegtestPanelRectangle, dx: number, dy: number, bounds: Size): SegtestPanelRectangle {
  const right = origin.left + origin.width;
  const maxWidth = Math.max(0, right - SEGTEST_EDGE_INSET);
  const maxHeight = Math.max(0, bounds.height - origin.top - SEGTEST_EDGE_INSET - SEGTEST_DOT_DIAMETER - SEGTEST_PANEL_GAP);
  const width = clamp(origin.width - dx, Math.min(MIN_PANEL_WIDTH, maxWidth), maxWidth);
  const height = clamp(origin.height + dy, Math.min(MIN_PANEL_HEIGHT, maxHeight), maxHeight);
  return { left: right - width, top: origin.top, width, height };
}

/** Offset coordinates match the panel's absolute-positioning container. */
function measurePanel(panel: HTMLDivElement): SegtestPanelRectangle {
  return { left: panel.offsetLeft, top: panel.offsetTop, width: panel.offsetWidth, height: panel.offsetHeight };
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function readRectangle(id: string): SegtestPanelRectangle | null {
  try {
    const stored: unknown = JSON.parse(window.localStorage.getItem(`segtest.panel.rectangle.${id}`) ?? "null");
    if (!stored || typeof stored !== "object") return null;
    const candidate = stored as SegtestPanelRectangle;
    return [candidate.left, candidate.top, candidate.width, candidate.height].every(Number.isFinite)
      && candidate.width > 0 && candidate.height > 0 ? candidate : null;
  } catch {
    return null;
  }
}
