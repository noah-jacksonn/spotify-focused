import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

type SegtestPicks = Record<string, Record<string, string>>;

/** One store per dev route: serialize row saves and publish complete JSON atomically. */
export function createSegtestPickStore(filePath: string) {
  let pendingSave: Promise<void> = Promise.resolve();

  async function read(): Promise<SegtestPicks> {
    try {
      return JSON.parse(await readFile(filePath, "utf8")) as SegtestPicks;
    } catch (error) {
      // Only an absent file means no picks yet. Do not overwrite unreadable data.
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return {};
      throw error;
    }
  }

  function save(id: string, title: string, value: string): Promise<void> {
    // Rows report together on mount. Read inside the queue so every save sees
    // the previous save, instead of each row overwriting the same old snapshot.
    const saveOperation = pendingSave.then(async () => {
      const picks = await read();
      const previousRows = Object.hasOwn(picks, id) ? picks[id] : {};
      const updated = { ...picks, [id]: { ...previousRows, [title]: value } };
      await mkdir(path.dirname(filePath), { recursive: true });
      const temporaryPath = `${filePath}.${randomUUID()}.tmp`;
      await writeFile(temporaryPath, `${JSON.stringify(updated, null, 2)}\n`);
      await rename(temporaryPath, filePath);
    });
    // A failed write is reported to its caller but must not poison later saves.
    pendingSave = saveOperation.catch(() => {});
    return saveOperation;
  }

  return { read, save };
}
