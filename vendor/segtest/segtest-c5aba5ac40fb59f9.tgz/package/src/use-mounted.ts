import * as React from 'react';

export function useMounted() {
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    // Hydration gate: the server cannot know browser storage or viewport size.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);

  return mounted;
}
