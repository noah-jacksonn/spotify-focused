/**
 * Modal libraries may cancel native touch scrolling at document level even
 * for a nested viewport. Own vertical swipes here so they still scroll, while
 * horizontal slider gestures and taps keep their normal browser behavior.
 */
export function attachTouchScroll(viewport: HTMLElement): () => void {
  let gesture: {
    x: number;
    y: number;
    top: number;
    axis: "horizontal" | "vertical" | null;
  } | null = null;

  const start = (event: TouchEvent) => {
    gesture = event.touches.length === 1
      ? { x: event.touches[0].clientX, y: event.touches[0].clientY, top: viewport.scrollTop, axis: null }
      : null;
  };
  const move = (event: TouchEvent) => {
    if (!gesture || event.touches.length !== 1) {
      gesture = null;
      return;
    }
    const dx = event.touches[0].clientX - gesture.x;
    const dy = event.touches[0].clientY - gesture.y;
    if (!gesture.axis && Math.max(Math.abs(dx), Math.abs(dy)) >= 6) {
      gesture.axis = Math.abs(dy) > Math.abs(dx) ? "vertical" : "horizontal";
    }
    if (gesture.axis !== "vertical") return;
    if (event.cancelable) event.preventDefault();
    event.stopPropagation();
    // The panel may sit under a scaled modal. Convert screen pixels back to
    // layout pixels, and clamp so changing direction at an edge feels natural.
    const scale = viewport.getBoundingClientRect().height / viewport.offsetHeight || 1;
    viewport.scrollTop = Math.max(0, Math.min(
      viewport.scrollHeight - viewport.clientHeight,
      gesture.top - dy / scale,
    ));
  };
  const end = (event: TouchEvent) => {
    // A swipe starting over an option must not become a tap when released.
    if (gesture?.axis === "vertical") {
      if (event.cancelable) event.preventDefault();
      event.stopPropagation();
    }
    gesture = null;
  };
  const options = { capture: true, passive: false };
  viewport.addEventListener("touchstart", start, options);
  viewport.addEventListener("touchmove", move, options);
  viewport.addEventListener("touchend", end, options);
  viewport.addEventListener("touchcancel", end, options);
  return () => {
    viewport.removeEventListener("touchstart", start, options);
    viewport.removeEventListener("touchmove", move, options);
    viewport.removeEventListener("touchend", end, options);
    viewport.removeEventListener("touchcancel", end, options);
  };
}
