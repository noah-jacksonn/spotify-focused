"use client";

import { createContext } from "react";

/** Shared by categorical and numeric rows so they use one persistence format. */
export const SegtestIdContext = createContext("default");

function pickKey(id: string, title: string) {
  return `segtest.pick.${id}.${title}`;
}

export function readSegtestPick(id: string, title: string): string | null {
  try {
    return window.localStorage.getItem(pickKey(id, title));
  } catch {
    return null;
  }
}

/** The development route mirrors picks for the agent's eventual lock-in. */
export function reportSegtestPick(id: string, title: string, value: string) {
  void fetch("/api/debug/segtest", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, title, value }),
  }).catch(() => {
    // A restarting dev server can catch up on the next change or row mount.
  });
}

export function saveSegtestPick(id: string, title: string, value: string) {
  try {
    window.localStorage.setItem(pickKey(id, title), value);
  } catch {
    // The live selection and server mirror still work when storage is blocked.
  }
  reportSegtestPick(id, title, value);
}
